Wtyczki nie są automatycznie dodawane. Muszą zostać dopisane do jstat.gui.Main.createMenuBar()
